function linkButtons() {
  var x = document.getElementById('tv-show');
  var y = document.getElementById('math');
  if (x.style.display === 'none') {
    x.style.display = 'block';
    y.style.display = 'block';

    window.setTimeout(function () {
      x.style.opacity = 1;
      x.style.transform = 'scale(1)';

      y.style.opacity = 1;
      y.style.transform = 'scale(1)';
    }, 0);
  }
  else {
    x.style.display = 'none';
    y.style.display = 'none';

    x.style.opacity = 0;
    x.style.transform = 'scale(0)';

    y.style.opacity = 0;
    y.style.transform = 'scale(0)';
    window.setTimeout(function () {
      x.style.display = 'none';
      y.style.display = 'none';
    }, 700);
  }
}


var modal = document.getElementById("myModal");
var btn = document.getElementById("tv-show");
var span = document.getElementsByClassName("close")[0];

btn.addEventListener('click', function() {
modal.style.display = "block";
});

span.onclick = function () {
  modal.style.display = "none";
}

window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

function displayArray(){
  const myArray = {
    'Chapter One': 'The Vanishing of Will Byers',
    'Chapter Two': 'The Weirdo on Maple Street',
    'Chapter Three': 'Holly, Jolly 53m',
    'Chapter Four': 'The Body 51m',
    'Chapter Five': 'The Flea and the Acrobat 5m',
    'Chapter Six': 'Chapter Six: The Monster 48m',
    'Chapter Seven': 'The Bathtub 43m',
    'Chapter Eight': 'The Upside Down',
  };

  var div = document.createElement('div');
  div.id = 'modal-content';
  
  modal.style.zIndex = '10';
  div.innerHTML = `
    <h2 id="heading"><strong>Stranger Things</strong></h2>
    <ul class="loop">
      ${Object.entries(myArray).map(([key, value]) => `<li>${key} : ${value}</li>`).join('')}
    </ul>
  `;
  modal.appendChild(div);

}














